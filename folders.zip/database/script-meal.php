<?php
	session_start();
	$_SESSION['detail']['mealType'] = $_GET['mealId'];
